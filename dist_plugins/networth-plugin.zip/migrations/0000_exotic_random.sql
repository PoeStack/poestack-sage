CREATE TABLE `rootStore` (
	`id` integer PRIMARY KEY NOT NULL,
	`root` text,
	`timestamp` text DEFAULT CURRENT_TIMESTAMP
);
